# Presentacion
 Hola mi nombre es  Nahuel Fleitas tengo 21 años y soy de Belén de Escobar 
 ## Hobbies
 Me gusta mucho hacer deporte en general , el gimnasio y la halterofilia .
 ### Trabajos
 actualmente trabajo de matricero y fui personal trainer 2 años 
 *aguante boca*
 ![pp](https://user-images.githubusercontent.com/80929104/112534198-8c5eef80-8d89-11eb-9f65-f6f85f1eb252.jpg)
